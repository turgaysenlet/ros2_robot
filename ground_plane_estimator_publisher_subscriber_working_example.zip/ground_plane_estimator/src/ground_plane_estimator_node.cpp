#include <cstdio>
#include <chrono>
#include <functional>
#include <memory>
#include <string>

#include "ground_plane_estimator/ground_plane_estimator_node.hpp"

using namespace std::chrono_literals;

GroundPlaneEstimatorNode::GroundPlaneEstimatorNode()
: Node("ground_plane_estimator_node"), count_(0)
{
  publisher_ = this->create_publisher<std_msgs::msg::String>("topic", 10);
  subscription_ = this->create_subscription<std_msgs::msg::String>("topic", 10, std::bind(&GroundPlaneEstimatorNode::topic_callback, this, std::placeholders::_1));
  timer_ = this->create_wall_timer(
  500ms, std::bind(&GroundPlaneEstimatorNode::timer_callback, this));
}

void GroundPlaneEstimatorNode::timer_callback()
{
  auto message = std_msgs::msg::String();
  message.data = "Hello, world! " + std::to_string(count_++);
  RCLCPP_INFO(this->get_logger(), "Publishing: '%s'", message.data.c_str());
  publisher_->publish(message);
}

void GroundPlaneEstimatorNode::topic_callback(const std_msgs::msg::String::SharedPtr msg) const
{
  RCLCPP_INFO(this->get_logger(), "I heard: '%s'", msg->data.c_str());
}

int main(int argc, char * argv[])
{
  (void) argc;
  (void) argv;

  printf("hello world ground_plane_estimator package\n");
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<GroundPlaneEstimatorNode>());
  rclcpp::shutdown();
  return 0;
}